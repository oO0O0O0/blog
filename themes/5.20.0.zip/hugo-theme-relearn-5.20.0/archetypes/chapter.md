+++
archetype = "chapter"
title = "{{ replace .Name "-" " " | title }}"
weight = X
+++

Lorem Ipsum.