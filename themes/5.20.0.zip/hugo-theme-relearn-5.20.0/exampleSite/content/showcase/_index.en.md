+++
title = "Showcase"
[_build]
  render = "always"
  list = "never"
  publishResources = true
+++

## [GoboLinux Wiki](https://wiki.gobolinux.org/) by NEONsys.org

![GoboLinux image](gobolinux.png?width=60pc)

## [BITS](https://bits-training.de/training/) by Dr. Lutz Gollan

![BITS image](bits-train.png?width=60pc)

## [Pamasol Electrics](https://pamasol.github.io/de/) by Pamasol

![Pamasol Electrics](pamasol-electrics-portal.png?width=60pc)
