+++
title = "Image Effects"
weight = 4
+++
{{< piratify >}}