+++
tags = ["Content"]
title = "Marrrkdown rules"
weight = 3
+++
{{< piratify >}}