+++
categories = ["taxonomy", "content"]
tags = "tutorrrial"
title = "Taxonomy"
weight = 7
+++
{{< piratify >}}