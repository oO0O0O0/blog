+++
title = "Menu extrrra shorrrtcuts"
weight = 5
+++
{{< piratify >}}